#ifndef __OJ_H__
#define __OJ_H__





int GetMaxValue(int nPapers, int nRemain, int paper[][2], double* pMaxValue);


#endif
